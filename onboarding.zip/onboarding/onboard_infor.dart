
class OnboardInfor {
  final String title;
  final String descriptions;
  final String image;


  OnboardInfor(
      {required this.title, required this.descriptions, required this.image});
}
