import 'package:budget_buddy/onboarding/onboard_infor.dart';

class Items {
  List<OnboardInfor> items = [
    OnboardInfor(
        title: "Primary Goal",
        descriptions: "Aims to help users effectively manage their finances by providing tools to track income, expenses, savings, and investments.  to empower users to set and stick to a budget, monitor their spending habits.",
        image: "assets/p2.jpg",
       
        ),
        

   OnboardInfor(
        title: "Familiar With Budget",
        descriptions: "Familiar With Budget could be a name for a finance app or a feature within a finance app. This name suggests a focus on helping users become familiar with budgeting practices and techniques.",
        image: "assets/image2.gif",
        
        ),

   OnboardInfor(
        title: "Reminder",
        descriptions: "A Reminder feature in a finance app would serve as a tool to help users stay on top of their financial commitments and deadlines. Here's how it could work.",
        image: "assets/r1.jpg",
        
        ),


     OnboardInfor(
        title: "Welcome to Budget Buddy",
        descriptions: "Welcome to our finance app, where every penny counts towards your financial success. Whether you're tracking expenses, setting budgets, or planning investments, we're here to empower your journey towards financial freedom.",
        image: "assets/w1.jpg",
        
        )
  ];
  
}
